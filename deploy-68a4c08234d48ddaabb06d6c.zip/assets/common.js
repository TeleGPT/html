
(function(){
  var hdr = document.getElementById('hdr');
  var menuLinks = document.querySelectorAll('a[href^="#"]');
  for (var i=0;i<menuLinks.length;i++){
    menuLinks[i].addEventListener('click', function(e){
      var id = this.getAttribute('href');
      if (id.length > 1 && document.querySelector(id)){
        e.preventDefault();
        document.querySelector(id).scrollIntoView({behavior:'smooth'});
        history.pushState(null,'',id);
        if (hdr) hdr.classList.remove('open');
      }
    });
  }
  var burger = document.querySelector('.burger');
  var backdrop = document.getElementById('menuBackdrop');
  function closeMenu(){ if(hdr) hdr.classList.remove('open'); }
  if (burger){ burger.addEventListener('click', function(){ hdr.classList.toggle('open'); }); }
  if (backdrop){ backdrop.addEventListener('click', closeMenu); }
  document.addEventListener('keydown', function(e){ if(e.key==='Escape'){ closeMenu(); }});
  document.addEventListener('click', function(e){
    if (!hdr.classList.contains('open')) return;
    var menu = hdr.querySelector('nav .menu');
    if (menu && !menu.contains(e.target) && !burger.contains(e.target)){ closeMenu(); }
  }, true);
})();
